
You can find the instructions on how to restore the demo database here:

https://github.com/aelassas/bookcars/wiki/Demo-Database
